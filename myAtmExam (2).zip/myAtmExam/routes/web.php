<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\mySignInController;
use App\Http\Controllers\myLoginController;
use App\Http\Controllers\myDashController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('SignUp');
});

Route::get('/transac', function () {
    return view('transac');
});


Route::get('SignUp', [mySigninController::class, 'SignIn']);
Route::get('LoginUser', [myLoginController::class,'Login']);
Route::get('DashBoard', [myDashController::class,'Dash']);
