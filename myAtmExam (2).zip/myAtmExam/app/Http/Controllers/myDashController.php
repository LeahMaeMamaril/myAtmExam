<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class myDashController extends Controller
{
    public function Dash(Request $request){
        $UserId = "UserId";
        $pass= 123456789;
    
        $context = ["UserId" => $UserId, "pass" => $pass];
    
        return view ('DashBoard', $context);
        }
}
