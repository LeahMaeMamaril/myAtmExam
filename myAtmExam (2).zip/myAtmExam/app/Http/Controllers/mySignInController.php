<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class mySigninController extends Controller
{
   public function SignIn(Request $request){

      $UserID = $request -> input ("userID");
      $pass= $request -> input ("123456789");
  
      $context = ["UserID" => $UserId, "pass" => $pass];
  

    return view ('SignUp', $context);
   }

}
