<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class myLoginController extends Controller
{
    public function Login(){
    $UserId = "UserId";
    $pass= 123456789;

    $context = ["UserId" => $UserId, "pass" => $pass];

    return view ('LoginUser', $context);
    }


    function userLogin (Request $req){
        $id = $req->input('userID');
        $pass = $req->input('userPASS');

        $checkLogin = DB::table('Accounts')->where(['userID'=>$Id,'userPass'=>$pass])->get();
        if(count($checkLogin) > 0){
            return view('dash');
        }
        else{
            echo "Login Failed";
        }
    }
}
