<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="http://127.0.0.1:8000">MY ATM</a>
    </div>
      <ul class="nav navbar-nav navbar-right">
      <a href=""><span class="glyphicon glyphicon-user">Trasaction</a>
      <a href="http://127.0.0.1:8000/LoginUser?">Logout</a>
    </ul>
  </div>
</nav>


<h1>Your Transaction<hr width="300px"></h1>
  <h2> Your Balance: 0</h1>
  <div class="insnav">
      <a href=""> &nbsp &nbsp &nbsp Deposit &nbsp &nbsp &nbsp</a>
      <a href=""> &nbsp &nbsp &nbsp Withdraw &nbsp &nbsp &nbsp</a>
<body>

