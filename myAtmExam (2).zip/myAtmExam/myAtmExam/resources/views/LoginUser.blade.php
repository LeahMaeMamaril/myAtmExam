<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <h1>LOGIN PAGE </h1>
    <center>
         <Form action = LoginUser method = "get">
             @csrf
                <input type = "text" name = "UserId" placeholder = "UserID"/>
                <input type = "text" name = "Passwrord" placeholder = "Password"/>
        </Form>

        <form action = "DashBoard" method = "get">
                 <button type = "DashBoard">login</button>
        </form>
    <center/>
</body>
</html>