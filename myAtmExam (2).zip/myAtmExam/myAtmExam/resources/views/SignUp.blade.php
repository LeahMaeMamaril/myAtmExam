<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1> SIGN UP PAGE </h1>

<center>
    <Form action = SignUp method = "get">
        @csrf
        <input type = int name = "UserId" placeholder = "UserID"/>
        <input type = int name = "Passwrord" placeholder = "Password"/>
    </Form>

    <form action = "LoginUser" method = "get">
         <button type = "Login">login</button>
    </form>
</center>
    
</body>
</html>