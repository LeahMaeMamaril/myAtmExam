<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>MY DASHBOARD</h1>


    <center>
        <form action= "DashBoard" method = "get">
              <h2>Leah Mae C. Mamaril</h2>
              <h3>Remaining Balance: ₱: 10,000.00</h3>
              <h4>Date last Widrawal: 02-14-2022</h4>
       </form>
    <center/>
</body>
</html><?php /**PATH C:\xampp\htdocs\myAtmExam\resources\views/DashBoard.blade.php ENDPATH**/ ?>