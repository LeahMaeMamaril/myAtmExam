<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class myLoginController extends Controller
{
    public function Login(){
    $UserId = "UserId";
    $pass= 123456789;

    $context = ["UserId" => $UserId, "pass" => $pass];

    return view ('LoginUser', $context);
    }
}
