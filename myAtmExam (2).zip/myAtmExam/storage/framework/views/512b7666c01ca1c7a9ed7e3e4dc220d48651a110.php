<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="http://127.0.0.1:8000">MY ATM</a>
    </div>
      <ul class="nav navbar-nav navbar-right">
      <li><a href="http://127.0.0.1:8000"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
      <li><a href="http://127.0.0.1:8000/LoginUser?"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
    </ul>
  </div>
</nav>
<body>
<body>

    <h1>LOGIN PAGE </h1>
    <center>
         <Form action = LoginUser method = "get">
             <?php echo csrf_field(); ?>
                <input type = "text" name = "UserId" placeholder = "UserID"/>
                <input type = "text" name = "Passwrord" placeholder = "Password"/>
        </Form>

        <form action = "DashBoard" method = "get">
                <button type = "DashBoard">login</button>
        </form>
    <center/>
</body>
</html><?php /**PATH C:\xampp\htdocs\myAtmExam\resources\views/LoginUser.blade.php ENDPATH**/ ?>